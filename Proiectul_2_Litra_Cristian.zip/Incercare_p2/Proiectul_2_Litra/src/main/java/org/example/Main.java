package org.example;

import staff.StaffControl;

public class Main {

    public static void main(String[] args) {

        StaffControl sc = StaffControl.getInstance();
        sc.exit();

    }
}
